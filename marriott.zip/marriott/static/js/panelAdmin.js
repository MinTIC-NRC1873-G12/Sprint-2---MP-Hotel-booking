$('button[data-bs-toggle="tab"]').on("click", function () {
  activeTab = $(this)[0].id;
  if (activeTab == "usuarios-tab") {
    console.log("ue");
  } else if (activeTab == "habitacion-tab") {
    var dataURL = "/getRooms";
    console.log("habitacion");
    $.ajax({
      method: "POST",
      url: dataURL,
      success: function (response) {
        habitaciones = response.habitaciones;
        habitaciones.forEach((element) => {
          addRooms(element);
        });
      },
    });
  } else {
    var dataURL = "/getAdmins";
    $.ajax({
      method: "POST",
      url: dataURL,
      success: function (response) {
        admin = response.administradores;
        console.log(admin);
        admin.forEach((element) => {
          addAdmin(element);
        });
      },
    });
    console.log(activeTab);
  }
});

var dataURL = "/getUsers";
$.ajax({
  method: "POST",
  url: dataURL,
  success: function (response) {
    usuarios = response.usuarios;
    usuarios.forEach((element) => {
      addRow(element, "");
    });
  },
});

function deleteTestPost(data) {
  var url = "/deleteTest";
  dataType: "json",
    $.ajax({
      method: "POST",
      url: url,
      data: data,
      success: function () {},
    });
}

function addRow(obj, usr) {
  var row = `<tr scope="row" style="cursor: pointer;"class="test-row-${obj.id}">
               <td id="name-${obj.id}" data-testid="${obj.id}">${
    obj.name ? obj.name : obj.id
  }</td>
                     <td id="lastname-${obj.id}" data-testid="${obj.id}">${
    obj.lastname ? obj.lastname : obj.camas
  }</td>
                     <td id="mail-${obj.id}" data-testid="${obj.id}"">${
    obj.mail ? obj.mail : obj.activa
  }</td>
                     <td>
                        <button class="btn btn-sm btn-success" data-toggle="modal" data-target="#ModalBooking"data-testid=${
                          obj.id
                        } id="booking-${obj.id}">Reservas</button>
                         <button class="btn btn-sm btn-danger" data-testid=${
                           obj.id
                         } id="delete-${obj.id}">Eliminar</button>
                         <button class="btn btn-sm btn-info" disabled data-testid="${
                           obj.id
                         }"  id="save-${obj.id}">Guardar</button>

                         <button class="btn btn-sm btn-danger hidden" data-testid="${
                           obj.id
                         }"  id="cancel-${obj.id}">Cancelar</button>
                         <button class="btn btn-sm btn-primary hidden" data-testid="${
                           obj.id
                         }"  id="confirm-${obj.id}">Confirmar</button>

                     </td>
             </tr>`;
  $(`#tests-table${usr}`).append(row);
  $(`#booking-${obj.id}`).on("click", viewBookingTest);
  $(`#delete-${obj.id}`).on("click", deleteTest);
  $(`#cancel-${obj.id}`).on("click", cancelDeletion);
  $(`#confirm-${obj.id}`).on(
    "click",
    { action: "deleteUser" },
    confirmDeletion
  );
  $(`#save-${obj.id}`).on("click", saveUpdate);

  $(`#lastname-${obj.id}`).on("click", { label: "lastname" }, editLastname);
  $(`#name-${obj.id}`).on("click", { label: "name" }, editLastname);
  $(`#mail-${obj.id}`).on("click", { label: "mail" }, editLastname);
}

function addRooms(obj) {
  var row = `<tr scope="row" class="test-row-${obj.idRoom}">
                 <td id="name-${obj.idRoom}" data-testid="${obj.idRoom}">${obj.idRoom}</td>
                       <td id="lastname-${obj.idRoom}" data-testid="${obj.idRoom}">${obj.name}</td>
                       <td id="mail-${obj.idRoom}" data-testid="${obj.idRoom}"">${obj.description}</td>
                       <td id="mail-${obj.idRoom}" data-testid="${obj.idRoom}"">${obj.rate}</td>
                       <td id="mail-${obj.idRoom}" data-testid="${obj.idRoom}"">${obj.capacity}</td>
  
                       <td id="mail-${obj.idRoom}" data-testid="${obj.idRoom}"">${obj.image}</td>
                       <td>
                          
                           <button class="btn btn-sm btn-danger" data-testid=${obj.idRoom} id="delete-${obj.idRoom}">Eliminar</button>
                           <!--<button class="btn btn-sm btn-info" disabled data-testid="${obj.idRoom}"  id="save-${obj.idRoom}">Guardar</button>-->
  
                           <button class="btn btn-sm btn-danger hidden" data-testid="${obj.idRoom}"  id="cancel-${obj.idRoom}">Cancelar</button>
                           <button class="btn btn-sm btn-primary hidden" data-testid="${obj.idRoom}"  id="confirm-${obj.idRoom}">Confirmar</button>
  
                       </td>
               </tr>`;
  $(`#hab-table`).append(row);
  //   $(`#booking-${obj.id}`).on("click", viewBookingTest);
  $(`#delete-${obj.idRoom}`).on("click", deleteTest);
  $(`#cancel-${obj.idRoom}`).on("click", cancelDeletion);
  $(`#confirm-${obj.idRoom}`).on(
    "click",
    { action: "deleteRoom" },
    confirmDeletion
  );
  //   $(`#save-${obj.idRoom}`).on("click", saveUpdate);

  //   $(`#lastname-${obj.id}`).on("click", { label: "lastname" }, editLastname);
  //   $(`#name-${obj.id}`).on("click", { label: "name" }, editLastname);
  //   $(`#mail-${obj.id}`).on("click", { label: "mail" }, editLastname);
}

function addAdmin(obj) {
  var row = `<tr scope="row" style="cursor: pointer;class="test-row-${obj.idAdmin}">

                         <td id="adname-${obj.idAdmin}" data-testid="${obj.idAdmin}">${obj.name}</td>
                         <td id="adlastname-${obj.idAdmin}" data-testid="${obj.idAdmin}"">${obj.lastname}</td>
                         <td id="admail-${obj.idAdmin}" data-testid="${obj.idAdmin}"">${obj.email}</td>

                         <td>
                             <button class="btn btn-sm btn-danger" data-testid=${obj.idAdmin} id="addelete-${obj.idAdmin}">Eliminar</button>
                             <button class="btn btn-sm btn-info" disabled data-testid="${obj.idAdmin}"  id="adsave-${obj.idAdmin}">Guardar</button>

                             <button class="btn btn-sm btn-danger hidden" data-testid="${obj.idAdmin}"  id="adcancel-${obj.idAdmin}">Cancelar</button>
                             <button class="btn btn-sm btn-primary hidden" data-testid="${obj.idAdmin}"  id="adconfirm-${obj.idAdmin}">Confirmar</button>

                         </td>
                 </tr>`;
  $(`#admin-table`).append(row);
  $(`#addelete-${obj.idAdmin}`).on("click", deleteTest);
  $(`#adcancel-${obj.idAdmin}`).on("click", cancelDeletion);
  $(`#adconfirm-${obj.idAdmin}`).on(
    "click",
    { action: "deleteAdmin" },
    confirmDeletion
  );
  //   $(`#save-${obj.idRoom}`).on("click", saveUpdate);

  $(`#adlastname-${obj.idAdmin}`).on(
    "click",
    { label: "lastname" },
    editLastname
  );
  $(`#adname-${obj.idAdmin}`).on("click", { label: "name" }, editLastname);
  $(`#admail-${obj.idAdmin}`).on("click", { label: "mail" }, editLastname);
}

function dataBookings(obj) {
  var row = `<tr scope="row" class="test-row-${obj.id}">
                 <td id="name-${obj.id}" data-testid="${obj.id}">${obj.idRoom}</td>
                       <td id="lastname-${obj.id}" data-testid="${obj.id}">${obj.checkin}</td>
                       <td id="mail-${obj.id}" data-testid="${obj.id}"">${obj.checkout}</td>
                       <td id="mail-${obj.id}" data-testid="${obj.id}"">${obj.rate}</td>
                       <td id="mail-${obj.id}" data-testid="${obj.id}"">${obj.comment}</td>

               </tr>`;
  $(`#bookings-table`).append(row);
}

function editLastname(label) {
  var label = label.data.label;
  console.log($(this).data("testid"));
  var testid = $(this).data("testid");
  var value = $(this).html();

  $(this).unbind();
  $(this).html(
    `<input class="${label} form-control" data-testid=${testid} id="input${label}-${testid}" type="text">`
  );

  $(`.${label}`).on("keyup", function () {
    var testid = $(this).data("testid");
    var saveBtn = $(`#save-${testid}`);
    saveBtn.prop("disabled", false);
  });
}

function saveUpdate() {
  console.log("Saved!");
  var testid = $(this).data("testid");
  var saveBtn = $(`#save-${testid}`);
  var row = $(`.test-row-${testid}`);

  saveBtn.prop("disabled", true);
  row.css("opacity", "0.5");
  console.log(`id-${testid}`);
  var name = $(`#inputname-${testid}`).val();
  var lastname = $(`#inputlastname-${testid}`).val();
  var email = $(`#inputmail-${testid}`).val();
  var data = { id: testid, name: name, lastname: lastname, email: email };

  udpateTestPost(data);
  console.log(data);

  setTimeout(function () {
    row.css("opacity", "1");
  }, 2000);
}

//// oculta o visibiliza botones de cancelar y confirmar
function deleteTest() {
  var testid = $(this).data("testid");

  var deleteBtn = $(`#delete-${testid}`);
  var saveBtn = $(`#save-${testid}`);
  var cancelBtn = $(`#cancel-${testid}`);
  var confirmBtn = $(`#confirm-${testid}`);

  var addeleteBtn = $(`#addelete-${testid}`);
  var adsaveBtn = $(`#adsave-${testid}`);
  var adcancelBtn = $(`#adcancel-${testid}`);
  var adconfirmBtn = $(`#adconfirm-${testid}`);

  deleteBtn.addClass("hidden");
  saveBtn.addClass("hidden");

  addeleteBtn.addClass("hidden");
  adsaveBtn.addClass("hidden");

  cancelBtn.removeClass("hidden");
  confirmBtn.removeClass("hidden");

  adcancelBtn.removeClass("hidden");
  adconfirmBtn.removeClass("hidden");
}

function viewBookingTest() {
  console.log("request", 1);
  var testid = $(this).data("testid");
  var dataURL = "/bookingTest";
  $.ajax({
    method: "POST",
    url: dataURL,
    data: { idUser: testid },
    success: function (response) {
      historicBooking = response.bookings;
      historicBooking.forEach((element) => {
        dataBookings(element);
      });
    },
  });
}

/// oculta opciones de confirmar y cancelar
function cancelDeletion() {
  var testid = $(this).data("testid");

  var deleteBtn = $(`#delete-${testid}`);
  var saveBtn = $(`#save-${testid}`);
  var cancelBtn = $(`#cancel-${testid}`);
  var confirmBtn = $(`#confirm-${testid}`);

  var addeleteBtn = $(`#addelete-${testid}`);
  var adsaveBtn = $(`#adsave-${testid}`);
  var adcancelBtn = $(`#adcancel-${testid}`);
  var adconfirmBtn = $(`#adconfirm-${testid}`);

  deleteBtn.removeClass("hidden");
  saveBtn.removeClass("hidden");

  cancelBtn.addClass("hidden");
  confirmBtn.addClass("hidden");

  addeleteBtn.removeClass("hidden");
  adsaveBtn.removeClass("hidden");

  adcancelBtn.addClass("hidden");
  adconfirmBtn.addClass("hidden");
}

/// en caso de confirmar delete borra registro
function confirmDeletion(action) {
  var action = action.data.action;

  var testid = $(this).data("testid");
  var row = $(`.test-row-${testid}`);
  row.remove();

  if (action == "deleteRoom") {
    data = { idRoom: testid };
  } else if (action == "deleteUser") {
    data = { idUser: testid };
  } else {
    data = { idAdmin: testid };
  }
  deleteTestPost(data);
}
// actualizar usuario
function udpateTestPost(data) {
  console.log(data);
  var url = "/updateTest";
  dataType: "json",
    $.ajax({
      method: "POST",
      url: url,
      data: data,
      success: function () {},
    });
}

///paso 1 crear usuario
$("#create-user").on("click", function () {
  var newId = 1;
  newUser = {
    name: $("#userName").val(),
    lastname: $("#userLastname").val(),
    mail: $("#userEmail").val(),
    password: $("#userPassword").val(),
  };

  if (newUser.name == null) {
    alert("No test selected!");
  } else {
    getUserLastId(newUser);
    $("#userName").val("");
    $("#userLastname").val();
    $("#userEmail").val();
    $("#userPassword").val();
  }
});

$("#create-admin").on("click", function () {
  var newId = 1;
  newAdmin = {
    name: $("#adminName").val(),
    lastname: $("#adminLastname").val(),
    email: $("#adminEmail").val(),
    password: $("#adminPassword").val(),
  };

  if (newAdmin.name == null) {
    alert("No test selected!");
  } else {
    getAdminLastId(newAdmin);
    $("#adminName").val("");
    $("#adminLastname").val();
    $("#adminEmail").val();
    $("#adminPassword").val();
  }
});

///paso 1 crear habitación
$("#create-room").on("click", function () {
  var newId = 1;
  newRoom = {
    // idRoom: $("#habCode").val(),
    name: $("#habName").val(),
    description: $("#habDescrip").val(),
    rate: $("#habRate").val(),
    capacity: $("#habCapacity").val(),
    image: $("#habImage").val(),
  };

  if (newRoom.name == null) {
    alert("No test selected!");
  } else {
    console.log(newRoom);

    // addRooms(newRoom);
    getRoomLastId(newRoom);

    // createTestPost(newRoom);

    // $("#habCode").val("");
    $("#habName").val("");
    $("#habDescrip").val("");
    $("#habRate").val("");
    $("#habCapacity").val("");
    $("#habImage").val("");
  }
});

function getUserLastId(data) {
  var url = "/lastUser";

  dataType: "json",
    $.ajax({
      method: "POST",
      url: url,
      success: function (response) {
        data.idUser = response.newId;
        addRow(data, "");
        createTestPost(data);
      },
    });
}

function getAdminLastId(data) {
  var url = "/lastAdmin";

  dataType: "json",
    $.ajax({
      method: "POST",
      url: url,
      success: function (response) {
        data.idAdmin = response.newId;
        addAdmin(data, "");
        console.log(data);
        createTestPost({ data: data });
      },
    });
}

function getRoomLastId(data) {
  var url = "/lastRoom";

  dataType: "json",
    $.ajax({
      method: "POST",
      url: url,
      success: function (response) {
        (data.idRoom = response.newId), console.log("ajax", data);
        addRooms(data);
        createTestPost(data);
      },
    });
}

function createTestPost(data) {
  var url = "/createTest";
  dataType: "json",
    $.ajax({
      method: "POST",
      url: url,
      data: { data },
      success: function (response) {},
    });
}
