var marriotApp = angular.module('marriotApp', ['ngAnimate', 'ngSanitize', 'ui.bootstrap', 'jkAngularRatingStars']);

marriotApp.directive('imageLoad', function () {
    return {
      link: function (scope, element, attrs) {
        scope.$watch(function () {
          //console.log(scope);
          return scope.image;
        }, function (value) {
          element.attr('src', value);
          //console.log(value);
        });
      }
    }
 });

marriotApp.controller("bookingManageController", function($scope, $http)
{
	let today = new Date();
	let nextDate = new Date();
	nextDate.setDate(nextDate.getDate() + 1);

    $scope.activeBooking = {
        image: undefined,
        name: undefined,
        lastname: undefined,
		checkin: undefined,
        checkout: undefined,
		minCheckin: today,
        totalGuests: undefined,
		capacity: undefined,
		room: undefined
    }

	$scope.lastBookingInfo = null;
	
    $scope.get_bookings = function()
    {
        $http({
			method: 'POST',
			url: '/booking_info',
			data: {
				statement: "getBookings"
			}
		}).then(function successCallback(response) {
			
			$scope.bookings = response.data;
			// console.log($scope.bookings);
		}, function errorCallback(response) {
			
		});
    }

    $scope.get_active_booking_info = function(idBooking)
    {
        $http({
			method: 'POST',
			url: '/booking_info',
			data: {
				statement: "getBookingInfo",
                idBooking: idBooking
			}
		}).then(function successCallback(response) {
			
			// $scope.activeBooking = response.data;
            $scope.bookingNumber = idBooking;
			$scope.image = response.data.image;
			$scope.activeBooking.name = response.data.name;
			$scope.activeBooking.lastname = response.data.lastname;
			$scope.activeBooking.checkin = new Date(response.data.checkin);
			$scope.activeBooking.checkout = new Date(response.data.checkout);
			$scope.activeBooking.totalGuests = response.data.totalGuests;
			$scope.activeBooking.capacity = response.data.capacity;
			$scope.activeBooking.room = response.data.roomNumber;
			$scope.bookingLoaded = true;

            // console.log(response.data);
		}, function errorCallback(response) {
			
		});
    }

	$scope.get_last_booking_info = function(idBooking)
    {
        $scope.lastBookingInfo = null;
		$http({
			method: 'POST',
			url: '/booking_info',
			data: {
				statement: "getLastBookingInfo",
                idBooking: idBooking
			}
		}).then(function successCallback(response) {
			// console.log(response.data);
			$scope.lastBookingInfo = response.data;
		}, function errorCallback(response) {
			
		});
    }

	$scope.edit_booking = function (idBooking)
	{
		// console.log("modificar reservación No. " + idBooking);
		$http({
			method: 'POST',
			url: '/booking_info',
			data: {
				statement: "editBooking",
                idBooking: idBooking,
				checkin: moment($scope.activeBooking.checkin).format('DD/MM/yyyy'),
				checkout: moment($scope.activeBooking.checkout).format('DD/MM/yyyy'),
				guests: $scope.activeBooking.totalGuests,
				room: $scope.activeBooking.room
			}
		}).then(function successCallback(response) {
			Swal.fire({
				icon: response.data.icon,
				title: response.data.title,
				text: response.data.text
			});
		}, function errorCallback(response) {
			
		});
	}

	$scope.rate_booking = function (idBooking, data)
	{
		// console.log("calificar reservación No. " + idBooking + " " + data.comment + " " + data.rate);
		$http({
			method: 'POST',
			url: '/booking_info',
			data: {
				statement: "rateLastBooking",
                idBooking: idBooking,
				comment: data.comment,
				rate: data.rate
			}
		}).then(function successCallback(response) {
			// console.log(response.data);
			Swal.fire({
				icon: response.data.icon,
				title: response.data.title,
				text: response.data.text
			});
		}, function errorCallback(response) {
			
		});
	}

	$scope.get_bookings();
});