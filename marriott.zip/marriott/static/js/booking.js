var marriotApp = angular.module('marriotApp', []);

marriotApp.controller("bookingController", function($scope, $http)
{
    $scope.get_booking_data = function()
    {
        $http({
			method: 'POST',
			url: '/booking_data'
		}).then(function successCallback(response) {
			
			console.log(response.data.filter);
		}, function errorCallback(response) {
			
		});
    }

    $scope.get_booking_data();
});