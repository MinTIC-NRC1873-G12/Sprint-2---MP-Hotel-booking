var marriotApp = angular.module('marriotApp', ['ngAnimate', 'ngSanitize', 'ui.bootstrap', 'jkAngularRatingStars']);

var INTEGER_REGEXP = /^-?\d+$/;
marriotApp.directive('integer', function() {
  return {
    require: 'ngModel',
    link: function(scope, elm, attrs, ctrl) {
      ctrl.$validators.integer = function(modelValue, viewValue) {
        if (ctrl.$isEmpty(modelValue)) {
          // consider empty models to be valid
          return true;
        }

        if (INTEGER_REGEXP.test(viewValue)) {
          // it is valid
          return true;
        }

        // it is invalid
        return false;
      };
    }
  };
});

marriotApp.directive('imageLoad', function () {
    return {
      link: function (scope, element, attrs) {
        scope.$watch(function () {
          //console.log(scope);
          return scope.image;
        }, function (value) {
          element.attr('src', value);
          //console.log(value);
        });
      }
    }
 });

marriotApp.directive('roomImg', function () {
    return {
      link: function (scope, element, attrs) {
        scope.$watch(function () {
          //console.log(scope);
          return scope.room.image;
        }, function (value) {
          element.attr('src', value);
          //console.log(value);
        });
      }
    }
 });

marriotApp.directive('dateField', function($filter) {
  return {
      require: 'ngModel',
      link: function(scope, element, attrs, ngModelController) {
           ngModelController.$parsers.push(function(data) {
              //View -> Model
               //console.log(data);
              var date = moment(data, 'YYYY-MM-DD', true);
               
              ngModelController.$setValidity('date', date.isValid());
               return date.isValid() ? moment(data).format('DD/MM/yyy') : undefined;
           });
           ngModelController.$formatters.push(function(data) {
              //Model -> View
              return $filter('date')(data, "yyyy-MM-dd");
           });    
       }
    }
});

marriotApp.filter('objLength', function() {
	return function(object) {
		return Object.keys(object).length;
	}
});

marriotApp.filter('roundup', function() {
  return function(input) {
    return Math.ceil(input);
  };
});


/* Controlador para el Home */
marriotApp.controller("homeController", function($scope, $http) 
{
	/* Variables */
	//##### Booking #####
	let today = new Date();
	let nextDate = new Date();
	nextDate.setDate(nextDate.getDate() + 1);

	$scope.booking = {
		checkin: today,
		checkout: nextDate,
		totalRooms: 1,
		totalGuests: 1,
		minCheckin: today
	};

	//##### Pagination #####
	$scope.numPerPage = 6;
	$scope.currentPage = 1;
	$scope.maxSize = 3;

	$scope.totalPages = 0;

	$scope.isLogged = false;

	/* Pagination Methods */
	get_total_pages = function(obj)
	{
		let objectSize = Object.keys(obj).length;
		let totalPages = 0;

		totalPages = Math.ceil(objectSize / $scope.numPerPage);

		return totalPages;
	}

	update_pagination = function() 
	{
		if($scope.rooms != null)
		{
			var begin = (($scope.currentPage - 1) * $scope.numPerPage)
			, end = begin + $scope.numPerPage;

			// console.log('init: ' + begin + ' end: ' + end);

			let sliced = Object.keys($scope.rooms).slice(begin, end).reduce((result, key) => {
				result[key] = $scope.rooms[key];
				return result;
			}, {});

			// console.log(sliced);

			// $scope.filteredTodos = $scope.todos.slice(begin, end);
			$scope.roomSliced = sliced;
		}
	}

	$scope.$watch('currentPage + numPerPage', update_pagination);

	/* Methods to get rooms */
	$scope.get_room_list = function ()
	{
		$http({
			method: 'POST',
			url: '/get_rooms',
			data:{
				statement: "getBestRatedRooms",
				filter: null
			}
		}).then(function successCallback(response) {
			$scope.totalPages = get_total_pages(response.data);
			// console.log('Total pages: ' + $scope.totalPages);
			$scope.rooms = response.data;

			update_pagination();

			$scope.roomsLoad = true;
		}, function errorCallback(response) {
			
		});
	}

	$scope.get_room_list_filter  = function ()
	{
		$scope.roomsLoad = false;
		$scope.rooms = null;

		let filter = {
			checkin: moment($scope.booking.checkin).format('DD/MM/yyyy'),
			checkout: moment($scope.booking.checkout).format('DD/MM/yyyy'),
			totalRooms: $scope.booking.totalRooms,
			totalGuests: $scope.booking.totalGuests
		};
		
		$http({
			method: 'POST',
			url: '/get_rooms',
			data:{
				statement: "getFilteredRooms",
				filter: filter
			}
		}).then(function successCallback(response) {
			$scope.rooms = response.data;
			$scope.totalPages = get_total_pages($scope.rooms);
			// console.log('Total pages: ' + $scope.totalPages);

			update_pagination();

			$scope.roomsLoad = true;
		}, function errorCallback(response) {
			
		});
	}

	$scope.reservar = function (room)
	{
		let filter = {
			checkin: moment($scope.booking.checkin).format('DD/MM/yyyy'),
			checkout: moment($scope.booking.checkout).format('DD/MM/yyyy'),
			totalRooms: $scope.booking.totalRooms,
			totalGuests: $scope.booking.totalGuests,
			room: room
		};

		$http({
			method: 'POST',
			url: '/load_booking_data',
			data:{
				filter: filter
			}
		}).then(function successCallback(response) {
			console.log("se cargo el dato");
			location.replace('/booking');
		}, function errorCallback(response) {
			
		});
	}

	/* Initialize Controller Methods */
	$scope.get_room_list();
});