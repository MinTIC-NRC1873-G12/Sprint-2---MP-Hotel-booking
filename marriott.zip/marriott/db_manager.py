import sqlite3
import os
import threading

lock_query = threading.Lock()

class DB_Manager(object):
	"""docstring for DB_Manager"""
	def __init__(self, arg):
		try:
			super(DB_Manager, self).__init__()
			self.__path = arg[0]
			self.__connection = None
			self.__cursor = None
		except Exception as exception:
			print("Exception: DB_Manager.__init__: {}".format(exception), flush=True)

	def exists(self, dbPath):
		try:
			if os.path.exists(dbPath):
				return True
			else:
				return False
		except Exception as exception:
			print("Exception: DB_Manager.exists: {}".format(exception), flush=True)

	def create(self, dbPath):
		try:
			dirname = os.path.dirname(__file__)

			if self.exists(dbPath) and self.__connection is None:
				self.__path = dbPath
				self.__connection = None
				self.__cursor = None
				print("1")
				return False
			else:
				self.__path = dbPath
				self.__connection = sqlite3.connect(self.__path, isolation_level='DEFERRED', check_same_thread = False)
				self.__connection.close()
				self.__connection = None
				self.__cursor = None
				print("2")
				return True
		except Exception as exception:
			print("Exception: DB_Manager.create: {}".format(exception), flush=True)

	def connect(self):
		try:
			if self.__path is not None:
				self.__connection = sqlite3.connect(self.__path)#, isolation_level='DEFERRED', check_same_thread = False)
				self.__cursor = self.__connection.cursor()
				return True
			else:
				return False
		except Exception as exception:
			print("Exception: DB_Manager.connect: {}".format(exception), flush=True)
			return -1

	def close(self):
		try:
			if self.__connection != None:
				self.__connection.close()
				self.__connection = None
				self.__cursor = None
				return True
			else:
				return False
		except Exception as exception:
			print("Exception: DB_Manager.close: {}".format(exception), flush=True)
			return -1

	def isTable(self, tableName):
		result = 0
		tables = []
		try:
			lock_query.acquire(True)

			query = "select tbl_name from sqlite_master where tbl_name = \'{}\'".format(tableName)
			if self.__connection is None:
				self.connect()
				tables = self.__cursor.execute(query).fetchone()
				result = 1 if tableName in tables else 0
				self.close()
			
		except Exception as exception:
			print("Exception: DB_Manager.execute_query: {}".format(exception), flush=True)
			result = -1
		finally:
			lock_query.release()
			return result

	def execute_query(self, query):
		result = None
		try:
			lock_query.acquire(True)

			if self.__connection == None:
				self.connect()
				self.__cursor.execute(query)
				#print(self.__cursor.description)
				result = self.__cursor.fetchall()
				self.__connection.commit()
				self.close()
		except Exception as exception:
			print("Exception: DB_Manager.execute_query: {}".format(exception), flush=True)
			result = -1
		finally:
			lock_query.release()
			return result

	def insert(self, query, data):
		result = None
		try:
			lock_query.acquire(True)

			if self.__connection == None:
				self.connect()
				self.__cursor.execute(query, data)
				result = self.__cursor.fetchall()
				self.__connection.commit()
				self.close()
		except Exception as exception:
			print("Exception: DB_Manager.insert: {}".format(exception), flush=True)
			result = -1
		finally:
			lock_query.release()
			return result