import os, time, csv
from datetime import datetime

runCode = False

dataPeak = {
	"waiting": False,
	"last": 0.0,
	"current": 0.0,
	"isDown": False,
	"threshold": 5.0
}

ecg = {
	"bpm": 0.0,
	"firstPeakTime": None,
	"lastPeakTime": None,
	"peakToCalculateBpm": 3,
	"peakCounter": 0,
	"waitingPeak": False,
	"peakValue": 0.0,
	"peakThreshold": 5.0,
	"isDown": False
}

def calculate_bpm(ecgValue):
	try:
		print("ECG Value: {}".format(ecgValue))

		if ecgValue >= ecg["peakThreshold"] and not ecg["waitingPeak"] and not ecg["isDown"]:
			ecg["waitingPeak"] = True
			ecg["peakValue"] = ecgValue

			print("peakThreshold superado, esperar")
			
			ecg["firstPeakTime"] = datetime.now()
		
		elif ecg["waitingPeak"] and ecgValue < ecg["peakValue"]:
			ecg["isDown"] = True
			ecg["waitingPeak"] = False

			ecg["lastPeakTime"] = datetime.now()

			diff = ecg["lastPeakTime"].timestamp() - ecg["firstPeakTime"].timestamp()

			print("firstPeakTime: {}".format(ecg["lastPeakTime"].timestamp()))
			print("lastPeakTime: {}".format(ecg["lastPeakTime"].timestamp()))
			"""print("diff: {}".format(diff.seconds))"""

			ecg["bpm"] = (1 / diff)
			
			print("esta bajando, Peak: {} - BPM: {}".format(ecg["peakValue"], ecg["bpm"]))
		
		elif ecg["isDown"] and ecgValue < ecg["peakThreshold"]:
			ecg["peakValue"] = None
			ecg["waitingPeak"] = False
			ecg["isDown"] = False
			print("Reiniciar")
		
		elif ecg["waitingPeak"] and not ecg["isDown"] and ecgValue >= ecg["peakValue"]:
			ecg["peakValue"] = ecgValue
			ecg["firstPeakTime"] = datetime.now()
	
	except Exception as exception:
		print("Exception: main.calculate_bpm - {}".format(exception))

def main():
	try:
		ecg = []
		rawFile = None

		with open('datos_paciente.csv', newline='') as f:
			reader = csv.reader(f)
			rawFile = list(reader)

			for data in rawFile:
				ecg.append(float(data[0]))

		print(ecg)

		for x in ecg:
			calculate_bpm(x)

			"""if x >= dataPeak["threshold"] and not dataPeak["waiting"] and not dataPeak["isDown"]:
				dataPeak["waiting"] = True
				dataPeak["last"] = x
				dataPeak["current"] = x

				print("threshold superado, esperar")
			
			elif dataPeak["waiting"] and x < dataPeak["last"]:
				dataPeak["isDown"] = True
				dataPeak["waiting"] = False
				print("Peak: {}".format(dataPeak["last"]))
				print("esta bajando")
			
			elif dataPeak["isDown"] and x < dataPeak["threshold"]:
				dataPeak["last"] = None
				dataPeak["waiting"] = False
				dataPeak["isDown"] = False
				print("Reiniciar")
			elif dataPeak["waiting"] and not dataPeak["isDown"] and x >= dataPeak["last"]:
				dataPeak["last"] = x"""



			time.sleep(0.01)


	except Exception as exception:
		print("Exception: main.main - {}".format(exception))
	except KeyboardInterrupt:
		print("Exception: main.KeyboardInterrupt", flush=True)
		runCode = False
	finally:
		print("termino")

if __name__ == "__main__":
	main()