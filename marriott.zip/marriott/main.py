from email.errors import MessageError
from tokenize import String
from click import password_option
from flask import Flask, jsonify, request, url_for, redirect, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin, login_user, LoginManager, login_required, logout_user, current_user
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, EmailField
from wtforms.validators import InputRequired, Length, ValidationError, Email
from flask_bcrypt import Bcrypt
from datetime import datetime
import json

import system

app = Flask(__name__)
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///marriott.db'
app.config['SECRET_KEY'] ='thisisasecretkey'
app.config['PREPARED'] = True

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'signin'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

##### Modelos de base de datos
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key = True, nullable=False, unique=True)
    name = db.Column(db.String(30), nullable=False)
    lastname = db.Column(db.String(30), nullable=False)
    email = db.Column(db.String(30), nullable=False, unique=True)
    password = db.Column(db.String(80), nullable=False)

class Admin(db.Model):
    idAdmin = db.Column(db.Integer, primary_key = True)
    name = db.Column(db.String(30), nullable=False)
    lastname = db.Column(db.String(30), nullable=False)
    email = db.Column(db.String(30), nullable=False, unique=True)
    password = db.Column(db.String(80), nullable=False)

class Room(db.Model):
    idRoom = db.Column(db.Integer, primary_key = True, nullable=False)
    name = db.Column(db.String(20), nullable=False)
    description = db.Column(db.String(50), nullable=False)
    rate = db.Column(db.Float, nullable=False)
    capacity = db.Column(db.Integer, nullable=False)
    image = db.Column(db.String(20), nullable=False)

class Booking(db.Model):
    idBooking = db.Column(db.Integer,primary_key = True, nullable=False)
    idUser = db.Column(db.Integer,db.ForeignKey('user.idUser'), nullable=False)
    idRoom = db.Column(db.Integer,db.ForeignKey('room.idRoom'), nullable=False)
    checkin = db.Column(db.DateTime, default=datetime.utcnow(), nullable=False)
    checkout = db.Column(db.DateTime, default=datetime.utcnow(), nullable=False)
    guests = db.Column(db.Integer, nullable=False)
    status = db.Column(db.Boolean, nullable=False)
    rate = db.Column(db.Float)
    comment = db.Column(db.String(100))

#### Formularios creados desde flask
class SignupForm(FlaskForm):
    username = StringField(
        validators=[
            InputRequired(), 
            Length(min=3, max=20)], 
        render_kw={
            'placeholder' : 'Nombre', 
            'class':'form-control'}
    )
    lastnames = StringField(
        validators=[
            InputRequired(), 
            Length(min=4, max=20)], 
            render_kw={
                'placeholder' : 'Apellidos', 
                'class':'form-control'}
    )
    email = EmailField(
        validators=[
            InputRequired(), 
            Length(min=4, max=20), 
            Email(granular_message = True, check_deliverability =  True,)
        ], 
            render_kw={
                'placeholder' : 'Correo electrónico', 
                'class' : 'form-control'}
    )
    password = PasswordField(
        validators=[
            InputRequired(), 
            Length(min=4, max=20)], 
        render_kw={
            'placeholder' : 'Contraseña', 
            'class': 'form-control'}
    )
    submit = SubmitField('Signup')

    def validate_email(self, email):
        existing_user_username = User.query.filter_by(email=email).first()

        if existing_user_username:
            return True
        else:
            return False

class SigninForm(FlaskForm):
    email = EmailField(
        validators=[
            InputRequired(), 
            Length(min=4, max=20)], 
        render_kw={
            'placeholder' : 'Correo electrónico', 
            'class' : 'form-control form-control-lg'}
    )
    password = PasswordField(
        validators=[
            InputRequired(), 
            Length(min=4, max=20)], 
        render_kw={
            'placeholder' : 'Contraseña', 
            'class': 'form-control form-control-lg'}
        )
    submit = SubmitField('Ingresar', render_kw = {'class' : 'btn-primary btn-lg px-5'})

def get_username():
    try:
        activeUser = current_user.name
    except AttributeError:
        activeUser = False
    finally:
        return activeUser

### definicion de vistas
@app.route('/', methods=['GET', 'POST'])
def home():
    try:
        return render_template("index.html", controller="homeController", activeUser=get_username())
    except Exception as exception:
        print("Exception - main.home: {}".format(exception), flush=True)
        return(str(exception))

@app.route('/get_rooms', methods=['GET', 'POST'])
def get_rooms_info():
    response = {}
    jsonRequest = {}
    query = None

    try:
        jsonRequest = request.get_json().copy()
        if "filter" in jsonRequest.keys() and "statement" in jsonRequest.keys():
            statement = jsonRequest["statement"]
            filter = jsonRequest["filter"]
            
            if filter == None and statement == "getBestRatedRooms":
                query = system.prepareStatement[statement].format(totalRows=6)
            
            elif statement == "getFilteredRooms":
                checkin = datetime.strptime(jsonRequest["filter"]["checkin"], '%d/%m/%Y').replace(hour=15)
                checkout = datetime.strptime(jsonRequest["filter"]["checkout"], '%d/%m/%Y').replace(hour=13)
                query = system.prepareStatement[statement].format(reqCheckin=checkin, reqCheckout=checkout)
            
            if query != None:
                result = db.engine.execute(query)
                response =  system.result_set_to_response(statement, result)
    except Exception as exception:
        print("main.get_rooms_info: {}".format(exception), flush=True)
    finally:
        return jsonify(response)

@app.route('/signin', methods=['GET', 'POST'])
def signin():
    try:
        messageError = ''
        form = SigninForm()
        if form.validate_on_submit():
            user = User.query.filter_by(email = request.form['email']).first()
            if user:
                if bcrypt.check_password_hash(user.password, request.form['password']):
                    login_user(user)

                    path = request.args.get('next')

                    if path is not None:
                        return redirect(path)
                    else:
                        return redirect(url_for('home'))
            messageError = 'No pudimos encontrar tu cuenta o la contraseña es incorrecta. Vuelve a intentarlo o haz clic en "¿Olvidaste tu contraseña?" para restablecerla.'
        if request.method == 'POST':
            email = request.form['email']
            password = request.form['password']
        return render_template('signin.html', form=form, messageError=messageError)
    except Exception as exception:
        print("Exception - main.signin: {}".format(exception), flush=True)
        return(str(exception))

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    try:
        messageError = ''
        form = SignupForm()
        
        if request.method == 'POST':
            if form.validate_email(request.form['email']) == False:
                hashed_password = bcrypt.generate_password_hash(request.form['password'])
                new_user = User(name=request.form['username'],
                                lastname=request.form['lastnames'], 
                                password=hashed_password, 
                                email=request.form['email'] 
                            )
                db.session.add(new_user)
                db.session.commit()
                return redirect(url_for('signin'))
            else:
                messageError = 'Ya existe una cuenta asociada al correo ingresado. Intenta de nuevo o Inicia tu sesión en Ingresa acá</b> .'
                # return redirect(url_for('signup'))

        return render_template('/signup.html', form=form, messageError = messageError, controller="signupController")
    except Exception as exception:
        print("Exception - main.signup: {}".format(exception), flush=True)
        return(str(exception))

@app.route('/logout', methods=['GET', 'POST'])
def logout():
    try:
        logout_user()
        return redirect(url_for('home'))
    except Exception as exception:
        print("Exception - main.logout: {}".format(exception), flush=True)
        return(str(exception))

@app.route('/signin_admin')
def signin_admin_page():
    try:
        return render_template("signinAdmin.html")
    except Exception as exception:
        return str(exception)

@app.route('/signup_admin')
def signup_admin_page():
    try:
        return render_template("signupAdmin.html")
    except Exception as exception:
        return str(exception)

####### panel administrator section
@app.route('/admin',methods=['GET','POST'])
def admin():
    return render_template("admin.html")


@app.route('/getUsers',methods=['POST'])
def getUser():
    dataUser = []
    usuarios = User.query.all()

    for i in usuarios:
        dataUser.append({"name":i.name,"id":i.id,"lastname":i.lastname,"mail":i.email})
        print(dataUser)

    return jsonify({'usuarios':dataUser})

@app.route('/getRooms',methods=['POST'])
def getRoom():
    dataHab = []
    rooms = Room.query.all()

    for i in rooms:
        dataHab.append({"idRoom":i.idRoom, "name":i.name, "description":i.description,
                        "rate":i.rate,"capacity":i.capacity,'image':i.image})

    return jsonify({'habitaciones':dataHab})

@app.route('/getAdmins',methods=['POST'])
def getAdmin():
    dataAdmin = []
    admins = Admin.query.all()

    for i in admins:
        dataAdmin.append({"idAdmin":i.idAdmin,"name":i.name,"lastname":i.lastname,"email":i.email})

    return jsonify({'administradores':dataAdmin})





@app.route('/lastRoom',methods=['POST'])
def lastRoom():
    rooms = Room.query.all()
    maxId = [i.idRoom for i in rooms]
    return jsonify({'newId':max(maxId)+1})

@app.route('/lastUser',methods=['POST'])
def lastUser():
    users = User.query.all()
    maxId = [i.id for i in users]
    return jsonify({'newId':max(maxId)+1})

@app.route('/lastAdmin',methods=['POST'])
def lastAdmin():
    admin = Admin.query.all()
    maxId = [i.idAdmin for i in admin]
    return jsonify({'newId':max(maxId)+1})

@app.route('/createTest',methods=['POST'])
def createTest():
    print('#'*10)
    print(request.form.keys())
    print('#'*10)
    try :
        newRoom = Room(
                name = request.form['data[name]'],
                description = request.form['data[description]'],
                rate = request.form['data[rate]'],
                capacity = request.form['data[capacity]'],
                image = request.form['data[image]'],
        )
        db.session.add(newRoom)
        db.session.commit()
    except KeyError:
        print('datos no coinciden para habitacion')

    try:
        new_user = User(name=request.form['data[name]'],
                    lastname=request.form['data[lastname]'],  
                    email=request.form['data[mail]'], 
                    password=request.form['data[password]']
                ) 

        db.session.add(new_user)
        db.session.commit()    

    except KeyError:
        print('datos no coinciden para usuario')

    try:
        new_admin = Admin(name=request.form['data[data][name]'],
                    lastname=request.form['data[data][lastname]'],  
                    email=request.form['data[data][email]'], 
                    password=request.form['data[data][password]']
                ) 

        db.session.add(new_admin)
        db.session.commit()   

        ### funcion enviar correo para recuperar contraseña 

    except KeyError:
        print('datos no coinciden para administrador')

   
    # else:
    #     Room.query.filter_by(idRoom=request.form['idRoom']).delete()
    # if request.method == 'POST':
    #     new_user = User(name=request.form['name'],
    #                 lastname=request.form['lastname'],  
    #                 email=request.form['mail'], 
    #                 password='luis1234'
    #             )
        # db.session.add(new_user)
        # db.session.commit()
     
        # print(request.form['name'])

    return json.dumps({'status':200})

def setValues(data,key):
    try:
        key = data.form[key]
        return key
    except KeyError:
        return False
        print('no existe key name')  
    
    

@app.route('/updateTest',methods=['POST'])
def updateTest():
    name = setValues(request,'name')
    lastname = setValues(request,'lastname')
    email = setValues(request,'email')
    usuario = User.query.get(request.form['id'])
    if name:
        usuario.name = name
    if lastname:
        usuario.lastname = lastname
    if email:
        usuario.email = email
    db.session.commit()
    return json.dumps({'status':200})
    
@app.route('/deleteTest',methods=['POST'])
def deleteTest():
    print()
    if 'idUser' in request.form.keys():
        User.query.filter_by(id=request.form['idUser']).delete()
    elif 'idRoom' in request.form.keys():
        Room.query.filter_by(idRoom=request.form['idRoom']).delete()
    else:
        Admin.query.filter_by(idAdmin=request.form['idAdmin']).delete()
    db.session.commit()



    return json.dumps({'status':200})

@app.route('/bookingTest',methods=['POST'])
def bookingsTest():
    dataBooking = []
    if request.method == 'POST':
        bookings = Booking.query.filter_by(idUser=request.form['idUser'])

        for booking in bookings:
            dataBooking.append({'idRoom':booking.idRoom,'checkin':str(booking.checkin),
            'checkout':str(booking.checkout),'rate':booking.rate,'comment':booking.comment})
    print('#'*5)
    print(dataBooking)
    print('#'*5)
    return jsonify({'bookings':dataBooking})

##### end admin section

@app.route('/password_change')
def password_change_page():
    try:
        return render_template("passwordChange.html")
    except Exception as exception:
        return str(exception)

@app.route('/password_change_admin')
def password_change_admin_page():
    try:
        return render_template("passwordChangeAdmin.html")
    except Exception as exception:
        return str(exception)

@app.route('/password_mail')
def password_mail_page():
    try:
        return render_template("passwordMail.html")
    except Exception as exception:
        return str(exception)

@app.route('/password_mail_admin')
def password_mail_admin_page():
    try:
        return render_template("passwordMailAdmin.html")
    except Exception as exception:
        return str(exception)


##### Booking and Booking Management
@app.route('/booking', methods=['GET', 'POST'])
@login_required
def booking_page():
    try:
        return render_template("booking.html", controller="bookingController")
    except Exception as exception:
        print("Exception - main.booking_page: {}".format(exception), flush=True)
        return str(exception)
    
@app.route('/booking_data', methods=['GET', 'POST'])
@login_required
def booking_data_info():
    response = {}

    try:
        try:
            activeUser = current_user.id
            response = system.var[activeUser]
            # system.var[activeUser]
        except AttributeError:
            activeUser = False
    except Exception as exception:
        print("Exception - main.booking_data_info: {}".format(exception))
    finally:
        print("response: {}".format(response))
        return jsonify(response)

@app.route('/load_booking_data', methods=['GET', 'POST'])
@login_required
def load_booking_data():
    response = {}
    jsonRequest = {}

    try:
        jsonRequest = request.get_json().copy()
        try:
            activeUser = current_user.id
            system.var[activeUser] = jsonRequest
        except AttributeError:
            activeUser = False
        
        response = {
            "result": 1
        }
    except Exception as exception:
        print("Exception - main.booking_data_info: {}".format(exception))
    finally:
        print("response: {}".format(response))
        return jsonify(response)

@app.route('/booking_manage', methods=['GET', 'POST'])
@login_required
def booking_manage_page():
    try:
        return render_template("bookingManage.html", controller="bookingManageController", activeUser=get_username())
    except Exception as exception:
        print("Exception - main.booking_manage_page: {}".format(exception), flush=True)
        return(str(exception))

@app.route('/booking_info', methods=['GET', 'POST'])
@login_required
def booking_manage_info():
    response = {}
    jsonRequest = {}
    result = None

    try:
        jsonRequest = request.get_json().copy()

        print("1") 
        
        if "statement" in jsonRequest.keys():
            statement = jsonRequest["statement"]
            query = None
            print(jsonRequest) 

            if statement == "editBooking" and 'idBooking' in jsonRequest.keys() and 'room' in jsonRequest.keys() and 'checkin' in jsonRequest.keys() and 'checkout' in jsonRequest.keys() and 'guests' in jsonRequest.keys():
                room = jsonRequest['room']
                checkin = datetime.strptime(jsonRequest["checkin"], '%d/%m/%Y').replace(hour=15)
                checkout = datetime.strptime(jsonRequest["checkout"], '%d/%m/%Y').replace(hour=13)
                query = system.prepareStatement["verifyNewBooking"].format(room=room, reqCheckin=checkin, reqCheckout=checkout)

                # print("statement: {}".format("verifyNewBooking"))
                # print("query to send: {}".format(query)) 

                if query is not None:
                    result = db.engine.execute(query)
                    query = None
                    rowCount = len(list(result))

                    if rowCount == 0:
                        result = None
                        idBooking = jsonRequest['idBooking']
                        guests = jsonRequest["guests"]
                        query = system.prepareStatement[statement].format(idBookingToEdit=idBooking, checkin=checkin, checkout=checkout, guests=guests)

                        print("statement: {}".format(statement))
                        print("query to send: {}".format(query))
                    else:
                        result = None
                        response = {
                            "icon": 'info',
                            # "title": 'Error!',
                            "text": 'La habitación no se encuentra disponible para la fecha.'
                        }

            
            elif statement == "getBookings":
                query = system.prepareStatement[statement].format(userEmail=current_user.email)
            
            elif (statement == "getBookingInfo" or statement == "getLastBookingInfo") and 'idBooking' in jsonRequest.keys():
                idBooking = jsonRequest['idBooking']
                query = system.prepareStatement[statement].format(idBookingToFind = idBooking)

            elif statement == "rateLastBooking" and 'idBooking' in jsonRequest.keys() and 'comment' in jsonRequest.keys() and 'rate' in jsonRequest.keys():
                idBooking = jsonRequest['idBooking']
                rate = jsonRequest['rate']
                comment = jsonRequest['comment']
                query = system.prepareStatement[statement].format(idBookingToRate=idBooking, rate=rate, comment=comment)

            # print("statement: {}".format(statement))
            # print("query to send: {}".format(query)) 

            if query != None:
                result = db.engine.execute(query)
                if result is not None:
                    response = system.result_set_to_response(statement, result).copy()
    except Exception as exception:
        print("Exception - main.booking_manage_info: {}".format(exception))
    finally:
        print("response: {}".format(response))
        return jsonify(response)
##### End Booking and Booking Management

def initialize_app():
    try:
        # system.db = db_manager.DB_Manager([system.dbList["marriott"]])
        db.create_all()
    except Exception as exception:
        print("Exception: main.initialize_app - {}".format(exception), flush=True)

def main():
    initialize_app()
    #print(system.db.execute_query("SELECT * FROM rooms"))
    
    # print(get_availables_rooms('2022-08-12 15:00:00', '2022-08-20 13:00:00'))
    #get_best_rated_rooms()
    app.run(host=system.server['host'], port=system.server['port'], debug=True)

if __name__ == "__main__":
    main()