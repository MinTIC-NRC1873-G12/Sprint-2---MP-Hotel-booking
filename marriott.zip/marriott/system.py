from multiprocessing.spawn import prepare

var = {}

db = None

server = {
    "host": '0.0.0.0',
    "port": 9006
}


dbList = {
    "marriott": "marriott.db"
}

prepareStatement = {
    "getBestRatedRooms": """SELECT * FROM room 
    ORDER BY rate DESC 
    LIMIT 0,{totalRows}""",

    "getFilteredRooms": """SELECT DISTINCT r.* 
    FROM room r 
    LEFT JOIN booking b ON (b.idRoom = r.idRoom AND 
    (('{reqCheckin}' BETWEEN b.checkin AND b.checkout OR '{reqCheckout}' BETWEEN b.checkin AND b.checkout) 
    OR 
    (b.checkin BETWEEN '{reqCheckin}' AND '{reqCheckout}' OR b.checkout BETWEEN '{reqCheckin}' AND '{reqCheckout}'))) 
    WHERE b.idRoom IS NULL""",

    "createdBooking": """INSERT INTO booking (idBooking, idUser, idRoom, checkin, checkout, guests, status)
    VALUES ({}, {}, {}, {}, {}, {}, {})""",

    "editBooking": """UPDATE booking 
    SET checkin = '{checkin}', checkout = '{checkout}', guests = {guests} 
    WHERE idBooking = {idBookingToEdit}""",

    "verifyNewBooking": """SELECT * FROM booking b 
    WHERE idRoom = {room} AND status = 1 AND 
    (('{reqCheckin}' BETWEEN b.checkin AND b.checkout) OR ('{reqCheckout}' BETWEEN b.checkin AND b.checkout))""",
    
    "getBookings": """SELECT b.idBooking, b.status FROM booking b 
    INNER JOIN user u ON u.id = b.idUser 
    WHERE u.email = '{userEmail}'""",

    "getBookingInfo": """SELECT r.image, r.idRoom, u.name, u.lastname, b.checkin, b.checkout, b.guests, r.capacity FROM booking b
    INNER JOIN room r ON r.idRoom = b.idRoom
    INNER JOIN user u ON u.id = b.idUser
    WHERE b.idBooking = {idBookingToFind}""",

    "getLastBookingInfo": """SELECT b.idBooking, b.rate, b.comment FROM booking b 
    WHERE b.idBooking = {idBookingToFind} AND b.status = 0""",

    "rateLastBooking": """UPDATE booking 
    SET rate = {rate}, comment = '{comment}' 
    WHERE idBooking = {idBookingToRate}"""
}

def result_set_to_response(statement, result):
    response = {}

    try:
        if statement in prepareStatement.keys():
            # resultList = list(result)
            if statement == "getBestRatedRooms" or statement == "getFilteredRooms":
                response = {
                    "{}".format(row[0]): {
                        "number": row[0],
                        "name": row[1], 
                        "description": row[2], 
                        "averageRate": row[3], 
                        "capacity": row[4], 
                        "image": row[5]
                    } for row in result
                }
            
            elif statement == "getBookings":
                response["active"] = []
                response["last"] = []

                for item in result:
                    key = 'active' if item[1] else 'last'
                    response[key].append(item[0])

                # for item in result:
                #     key = '{}'.format(item[0])
                #     resultDict[key] = {}
                #     for column, value in item.items():
                #         resultDict[key][column] = value
                
                print('response: {}'.format(response))
            
            elif statement == "getBookingInfo":
                for item in result:
                    response["image"] = item[0]
                    response["roomNumber"] = item[1] 
                    response["name"] = item[2] 
                    response["lastname"] = item[3] 
                    response["checkin"] = item[4] 
                    response["checkout"] = item[5] 
                    response["totalGuests"] =item[6]
                    response["capacity"] = item[7]

                print('response: {}'.format(response)) 

            elif statement == "getLastBookingInfo":
                response = {
                    "{}".format(row[0]): {
                        "rate": row[1],
                        "comment": row[2]
                    } for row in result
                }
            
            elif statement == "rateLastBooking":
                if result.rowcount > 0:
                    response = {
                        "icon": 'success',
                        # "title": 'OK!',
                        "text": 'La calificación fue actualizada satisfactoriamente.'
                    }
                else:
                    response = {
                        "icon": 'error',
                        # "title": 'Error!',
                        "text": 'No se pudo actualizar la calificación. Intenta de nuevo.'
                    }
                print(result.rowcount)
            
            elif statement == "createdBooking":
                if result.rowcount > 0:
                    response = {
                        "icon": 'success',
                        "title": 'OK!',
                        "text": 'Su calificación fue registrada!'
                    }
                else:
                    response = {
                        "icon": 'error',
                        "title": 'Error!',
                        "text": 'Su calificación no pudo ser registrada!'
                    }
            
            elif statement == "editBooking":
                if result.rowcount > 0:
                    response = {
                        "icon": 'success',
                        # "title": 'OK!',
                        "text": 'Reversa modificada satisfactoriamente!'
                    }
                else:
                    response = {
                        "icon": 'error',
                        # "title": 'Error!',
                        "text": 'No se puede modificar la reserva. Intenta de nuevo.'
                    }
    except Exception as exception:
        print("Exception - system.result_set_to_response: {}".format(exception))
        response = None
    finally:
        return response
